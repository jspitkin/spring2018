# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util
import math

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"
        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Game state information
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()

        # Ignore the 'Stop' action to improve finish time
        if action == 'Stop':
            return 0

        # Check if this action will cause a collision with a ghost
        for ghostState in successorGameState.getGhostStates():
            if ghostState.getPosition() == newPos:
                return 0

        # Check if this action will get a food pellet
        # Return 2 so this beats a MD score of 1 from another action
        if currentGameState.getNumFood() > successorGameState.getNumFood():
            return 2

        # Otherwise return the reciprocal of the closest pellet
        foodManDists = [util.manhattanDistance(newPos, x) for x in newFood.asList()]
        return 1.0 / min(foodManDists)


def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.
        """
        maxAction = None
        maxActionValue = float("-inf")
        for action in gameState.getLegalActions(0):
            actionState = gameState.generateSuccessor(0, action)
            actionValue = self.value(actionState, 1, 0)
            if actionValue > maxActionValue:
                maxActionValue = actionValue
                maxAction = action
        return maxAction

    def value(self, gameState, level, depth):
        agent = level % gameState.getNumAgents()
        if agent == 0:
            depth += 1
        if depth == self.depth or gameState.isWin() or gameState.isLose():
            return self.evaluationFunction(gameState)
        if agent == 0:
            return self.maxValue(gameState, level, depth)
        return self.minValue(gameState, level, depth)

    def maxValue(self, gameState, level, depth):
        maxVal = float("-inf")
        agent = level % gameState.getNumAgents()
        for action in gameState.getLegalActions(agent):
            actionState = gameState.generateSuccessor(agent, action)
            maxVal = max(maxVal, self.value(actionState, level+1, depth))
        return maxVal

    def minValue(self, gameState, level, depth):
        minVal = float("inf")
        agent =  level % gameState.getNumAgents()
        for action in gameState.getLegalActions(agent):
            actionState = gameState.generateSuccessor(agent, action)
            minVal = min(minVal, self.value(actionState, level+1, depth))
        return minVal

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        maxAction = None
        maxActionValue = float("-inf")
        alpha = float("-inf")
        beta = float("inf")
        for action in gameState.getLegalActions(0):
            actionState = gameState.generateSuccessor(0, action)
            actionValue = self.value(actionState, 1, 0, alpha, beta)
            if actionValue > maxActionValue:
                maxActionValue = actionValue
                maxAction = action
            alpha = max(alpha, maxActionValue)
        return maxAction

    def value(self, gameState, level, depth, alpha, beta):
        agent = level % gameState.getNumAgents()
        if agent == 0:
            depth += 1
        if depth == self.depth or gameState.isWin() or gameState.isLose():
            return self.evaluationFunction(gameState)
        if agent == 0:
            return self.maxValue(gameState, level, depth, alpha, beta)
        return self.minValue(gameState, level, depth, alpha, beta)

    def maxValue(self, gameState, level, depth, alpha, beta):
        maxVal = float("-inf")
        agent = level % gameState.getNumAgents()
        for action in gameState.getLegalActions(agent):
            actionState = gameState.generateSuccessor(agent, action)
            maxVal = max(maxVal, self.value(actionState, level+1, depth, alpha, beta))
            if maxVal > beta:
                return maxVal
            alpha = max(alpha, maxVal)
        return maxVal

    def minValue(self, gameState, level, depth, alpha, beta):
        minVal = float("inf")
        agent =  level % gameState.getNumAgents()
        for action in gameState.getLegalActions(agent):
            actionState = gameState.generateSuccessor(agent, action)
            minVal = min(minVal, self.value(actionState, level+1, depth, alpha, beta))
            if minVal < alpha:
                return minVal
            beta = min(beta, minVal)
        return minVal

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        maxAction = None
        maxActionValue = float("-inf")
        for action in gameState.getLegalActions(0):
            actionState = gameState.generateSuccessor(0, action)
            actionValue = self.value(actionState, 1, 0)
            if actionValue > maxActionValue:
                maxActionValue = actionValue
                maxAction = action
        return maxAction

    def value(self, gameState, level, depth):
        agent = level % gameState.getNumAgents()
        if agent == 0:
            depth += 1
        if depth == self.depth or gameState.isWin() or gameState.isLose():
            return self.evaluationFunction(gameState)
        if agent == 0:
            return self.maxValue(gameState, level, depth)
        return self.expValue(gameState, level, depth)

    def maxValue(self, gameState, level, depth):
        maxVal = float("-inf")
        agent = level % gameState.getNumAgents()
        for action in gameState.getLegalActions(agent):
            actionState = gameState.generateSuccessor(agent, action)
            maxVal = max(maxVal, self.value(actionState, level+1, depth))
        return maxVal

    def expValue(self, gameState, level, depth):
        agent =  level % gameState.getNumAgents()
        values = []
        weights = []
        for action in gameState.getLegalActions(agent):
            actionState = gameState.generateSuccessor(agent, action)
            actionValue = self.value(actionState, level+1, depth)
            values.append(actionValue)
            weights.append(1.0 / len(gameState.getLegalActions(agent)))
        return self.expectation(values, weights)

    def expectation(self, values, weights):
        expectation = 0
        for i, val in enumerate(values):
            expectation += val * weights[i]
        return expectation

def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: See analysis document.
    """
    pos = currentGameState.getPacmanPosition()
    food = currentGameState.getFood().asList()
    capsules = currentGameState.getCapsules()
    gameScore = currentGameState.getScore()
    foodManDists = [util.manhattanDistance(pos, x) for x in food]
    capsuleManDists = [util.manhattanDistance(pos, x) for x in capsules]
    
    if len(foodManDists) == 0:
        foodManDists = [0.1]
    if len(capsuleManDists) == 0:
        capsuleManDists = [0.1]

    score = 1.0 / min(foodManDists)
    score += gameScore
    score += 1.0 / max(capsuleManDists)
    score -= len(capsules) * 21
    return score

# Abbreviation
better = betterEvaluationFunction

